<?php

namespace Ahy\Authorizenet\Magewire\HyvaCheckout;

use Hyva\Checkout\Model\Magewire\Component\EvaluationInterface;
use Hyva\Checkout\Model\Magewire\Component\EvaluationResultFactory;
use Hyva\Checkout\Model\Magewire\Component\EvaluationResultInterface;
use Magewirephp\Magewire\Component;
use Magento\Checkout\Model\Session;
use Ahy\Authorizenet\Service\AuthorizeNetApi;
use Magento\Framework\Event\ManagerInterface as EventManager;
use Magento\Framework\Message\ManagerInterface as MessageManagerInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartInterface;
use Exception;
use Magento\Framework\Exception\CouldNotSaveException;
use Ahy\Authorizenet\Helper\Data;

class AuthorizeNet extends Component implements EvaluationInterface
{
    protected $eventManager;
    protected $checkoutSession;
    protected $quoteRepository;
    protected $paymentInfo;
    protected $_authorizeNetApi;
    protected $_grandTotal;
    protected $_helperData;
    protected $quote;
    public $cardDetails = 'NA';
    public $cardNumber = null;
    public $expireMonth = null;
    public $expireYear = null;
    public $cardCvv = null;
    public $checkboxChecked;

    public function __construct(
        AuthorizeNetApi             $authorizeNetApi,
        Session                     $checkoutSession,
        CartRepositoryInterface     $quoteRepository,
        CartInterface               $cartInterface,
        Data                        $helperData,
        EventManager                $eventManager
    ) {
        $this->_authorizeNetApi     = $authorizeNetApi;
        $this->eventManager         = $eventManager;
        $this->checkoutSession      = $checkoutSession;
        $this->quoteRepository      = $quoteRepository;
        $this->quote                = $cartInterface;
        $this->_helperData          = $helperData;
    }

    public function createCharge()
    {
        try {
            $encryptionKey = $this->_helperData->getEncryptionKey();
            $cardNumber    = $this->_decryptSession('B4yPd7T5mWuR', $encryptionKey);
            $expMonth      = $this->_decryptSession('V3g6dC4hQ9m8X2L5', $encryptionKey);
            $expYear       = $this->_decryptSession('L8wKSe1cUVm', $encryptionKey);
            $cvv           = $this->_decryptSession('kzgD3B7n', $encryptionKey);
            $grandTotal    = $this->_decryptSession('grandTotal', $encryptionKey);

            // Step 1: Process payment
            $paymentResponse = $this->_authorizeNetApi->createTransactionRequest(
                $cardNumber,
                $expMonth,
                $expYear,
                $cvv,
                $grandTotal
            );

            if (!$paymentResponse || $paymentResponse->getTransactionResponse() === null) {
                throw new Exception('Transaction failed or returned empty response.');
            }

            $transactionId = $paymentResponse->getTransactionResponse()->getTransId();

            // Step 2: Create Customer Profile from Transaction
            $profileResponse = $this->_authorizeNetApi->createCustomerProfileFromTransaction($transactionId);

            // TEMP: Log to file for debug
            $responseData = json_encode([
                'transactionId' => $transactionId,
                'profileId'     => $profileResponse->getCustomerProfileId(),
                'paymentProfileId' => $profileResponse->getCustomerPaymentProfileIdList()
            ], JSON_PRETTY_PRINT);

            file_put_contents(BP . '/var/log/authorize_profile_create.log', $responseData);

            return $profileResponse;

        } catch (Exception $e) {
            file_put_contents(BP . '/var/log/authorize_profile_create_error.log', $e->getMessage());
            return false;
        }
    }

    private function _decryptSession($key, $encryptionKey)
    {
        $encrypted = $this->checkoutSession->getData($key);
        $method    = 'aes-256-cbc';
        $key       = substr(hash('sha256', $encryptionKey), 0, 32);
        $decoded   = base64_decode($encrypted);
        $iv        = substr($decoded, 0, 16);
        $data      = substr($decoded, 16);
        return openssl_decrypt($data, $method, $key, OPENSSL_RAW_DATA, $iv);
    }


    private function _storeDataInSessionVariable()
    {
        // Perform validation
        $encryptionKey      = $this->_helperData->getEncryptionKey();
        $quoteId            = $this->checkoutSession->getQuoteId();
        $quote              = $this->quoteRepository->get($quoteId);
        $this->_grandTotal  = $quote->getGrandTotal();
        // Store data in the session
        $this->checkoutSession->setData('B4yPd7T5mWuR',         $this->_encrypt($this->cardNumber   ?? 0,   $encryptionKey));
        $this->checkoutSession->setData('V3g6dC4hQ9m8X2L5',     $this->_encrypt($this->expireMonth  ?? 0,   $encryptionKey));
        $this->checkoutSession->setData('L8wKSe1cUVm',          $this->_encrypt($this->expireYear   ?? 0,   $encryptionKey));
        $this->checkoutSession->setData('kzgD3B7n',             $this->_encrypt($this->cardCvv      ?? 0,   $encryptionKey));
        $this->checkoutSession->setData('grandTotal',           $this->_encrypt($this->_grandTotal  ?? 0,   $encryptionKey));
        // if (!empty($this->cardNumber) ) {
        //     // Return true if the data is successfully stored
        //     return true;
        // }
        // // Return false if any of the variables are null or empty
        // return true;
    }

    private function _encrypt($dataString, $key)
    {
        $method             = 'aes-256-cbc';
        $key                = substr(hash('sha256', $key), 0, 32);
        $iv                 = random_bytes(16);
        $encryptedData      = openssl_encrypt($dataString, $method, $key, OPENSSL_RAW_DATA, $iv);
        $encryptedString    = base64_encode($iv . $encryptedData);
        return base64_encode($iv . $encryptedData);
    }

    public function evaluateCompletion(EvaluationResultFactory $resultFactory): EvaluationResultInterface
    {
        // card validation
        
        $this->_storeDataInSessionVariable();

        return $resultFactory->createSuccess();

    }
}
